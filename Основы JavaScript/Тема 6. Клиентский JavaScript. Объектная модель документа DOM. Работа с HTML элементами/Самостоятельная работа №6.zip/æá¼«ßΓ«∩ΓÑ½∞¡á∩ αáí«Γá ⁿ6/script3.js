{
	"use strict";
	function setStyle(fontColor, fontSize) {

		let textOfLi = [];
		let nodes = document.getElementsByClassName('listNumbers')[0].childNodes;

		nodes.forEach(item => {
			if (item.nodeType == 1) {
				item.style.color = fontColor;
				item.style.padding = fontSize;
			}
		});
	}

		let fontColor = prompt('Задайте цвет: ', 'blue');
		let fontSize = prompt('Задайте размер: ', '15px');

		setStyle(fontColor, fontSize);
}