{
	"use strict";
	first  = document.getElementById('first');
	second = document.getElementById('second');
	console.log(first, second);
}