{
	"use strict";
	function getForm() {

			let dict_form = {};

			dict_form['name'] = document.getElementById('name').value;
			dict_form['surname'] = document.getElementById('surname').value;
			dict_form['age'] = document.getElementById('age').value;


			polInputs = document.getElementsByName('sex');

			let result = {};
			let res = {};

			for (let i=0; i < polInputs.length; i++) {

				if (polInputs[i].checked) {
					res = {value: polInputs[i].value, status: 'checked'};					
				} else {
					res = {value: polInputs[i].value, status: 'false'};
				}

				result[i] = res;
			}
			
			dict_form['sex'] =  result;
			return dict_form;
		}

		console.log(getForm());
}