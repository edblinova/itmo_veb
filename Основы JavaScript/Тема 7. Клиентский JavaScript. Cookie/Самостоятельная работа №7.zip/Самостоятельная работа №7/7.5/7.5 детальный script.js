"use strict";

let login = () => {
	//Считываем данные с поля ввода login и password
	let username = document.getElementById('login').value;
	let password = document.getElementById('password').value;
	//Проверяем верность введенных данных
	if (username == 'stanislav' && password == 'pass') {
		//Добавляем в куки login и password
		Cookies.set('login', username);
		Cookies.set('password', password);
		//Это хук, который позволяем изменить внешний вид страницы без перезагрузки.
		checkStatus();
		//можно конечно было сделать location.reload(); но можно вручную функцией.
	} else {
		//Если произошла ошибка добавляем сообщение об ошибке под форму в элемент .info
		document.getElementsByClassName('info')[0].innerHTML = '<strong>Неверный логин или пароль!</strong>';
	}
}
let logout = async () => {
	//Удаляем из куков login и password
	//Ваш код...
	Cookies.remove('login');
	Cookies.remove('password');
	//Это хук, который позволяем изменить внешний вид страницы без перезагрузки.
	checkStatus();
	//можно конечно было сделать location.reload(); но можно вручную функцией.
}
let checkStatus = () => {
	//Получаем значения login и password из куков
	let login = Cookies.get('login');
	let pass = Cookies.get('password');
	//Проверяем верность хранимых данных
	if (login == 'stanislav' && pass == 'pass') {
		//Если логин и пароль совпали, то показываем приветствие и скрываем форму авторизации
		document.getElementsByClassName('formAuth')[0].style.display = 'none';
		document.getElementsByClassName('greetings')[0].style.display = 'block';
		//а также добавляем текст к приветствию. Т.е. кого приветствуем
		document.querySelector('.greetings p span').innerText = login;
	} else {
		//Если логин и пароль не совпали, то показываем форму авторизации и скрываем
		приветствие
		document.getElementsByClassName('formAuth')[0].style.display = 'block';
		document.getElementsByClassName('greetings')[0].style.display = 'none';
	}
	//Куда же без костылей (https://ru.wikipedia.org/wiki/Обходной_приём)
	//Удаляем введенные данные с input-ов и убираем сообщение об ошибке если было в элементе
	.info
	document.getElementsByClassName('info')[0].innerHTML = '';
	document.getElementById('login').value = '';
	document.getElementById('password').value = '';
}