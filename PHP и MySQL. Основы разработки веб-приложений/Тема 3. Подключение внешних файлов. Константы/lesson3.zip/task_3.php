<?php
echo "<i>include_once</i> может использоваться в тех случаях, когда один и тот же файл может быть включён и выполнен более одного раза во время выполнения скрипта<br />";

echo "<br /><i>include</i>:";
include "first.php";  // включим файл

echo "<br /><i>require</i>:";
require "first.php";  // включим файл снова

echo "<br /><i>include_once</i>:";
include_once "first.php";  // не включим файл, если уже есть

echo "<br /><i>require_once</i>:";
require_once "first.php";  // не включим файл, если уже есть
?>