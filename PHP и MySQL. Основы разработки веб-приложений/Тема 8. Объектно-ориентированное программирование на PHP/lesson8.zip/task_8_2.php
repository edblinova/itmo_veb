<?php
class User
{
	protected $name;
	protected $age;

	public function setName($my_name){
		$this->name = $my_name;
	}
	public function getName(){
		return $this->name;
	}
	public function setAge($my_age){
		$this->age = $my_age;
	}
	public function getAge(){
		return $this->age;
	}
}

class Worker extends User
{
	private $salary;

	public function setSalary($my_salary){
		$this->salary = $my_salary;
	}
	public function getSalary(){
		return $this->salary;
	}
}

$st1 = new Worker;
$st2 = new Worker;

$st1->setName('Иван');
$st2->setName('Вася');

$st1->setAge(25);
$st2->setAge(26);

$st1->setSalary(1000);
$st2->setSalary(2000);

echo $st1->getSalary() + $st2->getSalary();
?>