<?php
class Student
{
	private $name;
	private $age;
	private $group;

	public function setName($my_name){
		$this->name = $my_name;
	}
	public function getName(){
		return $this->name;
	}
	public function setAge($my_age){
		$this->age = $my_age;
	}
	public function getAge(){
		return $this->age;
	}
	public function setGroup($my_group){
		$this->group = $my_group;
	}
	public function getGroup(){
		return $this->group;
	}
}

$st1 = new Student;
$st2 = new Student;

$st1->setName('Иван');
$st2->setName('Вася');

$st1->setAge(21);
$st2->setAge(20);

$st1->setGroup('U1001');
$st2->setGroup('U1002');

echo $st1->getGroup(),"\n",$st2->getGroup(),"\n",$st1->getAge() + $st2->getAge();
?>