<?php
   $yes = 0;
   $not = 0;
      if ($_POST[q1] == "Путин"){$yes++;} else {$not++;}
      if ($_POST[q2] == "366"){$yes++;} else {$not++;}
?>

<!DOCTYPE HTML>
<html>
   <head>
   </head>
   <body>
      <p>Правильных ответов: <?php echo $yes; ?><br>
      Неправильных ответов: <?php echo $not; ?><br><br><br>
      Вопрос 1. Кто является президентом России?<br>
      Вы ответили - <?php echo $_POST[q1]; ?>, правильно - Путин<br><br>
      Вопрос 2. Сколько дней в високосном году?<br>
      Вы ответили - <?php echo $_POST[q2]; ?>, правильно - 366</p>
   </body> 
</html>
