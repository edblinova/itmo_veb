<form name="authForm" method="POST">
n=<input type="text" name="n">
</form>

<?php
$n=(int)$_POST['n'];
function secret($n){
	if($n > 0) {
		return $n * secret($n-1);
	}
	return 1;
}
$r = secret($n);
echo $r;
?>