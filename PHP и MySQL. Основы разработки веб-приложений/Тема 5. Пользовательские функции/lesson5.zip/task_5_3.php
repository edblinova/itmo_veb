<form name="authForm" method="POST">
n=<input type="text" name="n">
</form>

<?php
$n=$_POST['n'];
function change($n){
	$n = 'Hello world';
	echo $n;
}
change($n);
?>
