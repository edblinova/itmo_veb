<?
session_start();
// Разрегистрировали переменную
unset($_SESSION['username']);
unset($_SESSION['email']);
// Разрушаем сессию
session_destroy();
?>
