<?php
mb_internal_encoding("UTF-8");
$text_1 = "Теперь пора всем хорошим людям прийти на помощь стране";
$text_1 = explode(" ", $text_1);

$text_2 = array($text_1[1], $text_1[0], $text_1[8], $text_1[5], $text_1[6], $text_1[7], $text_1[2], $text_1[3], $text_1[4]);

$text_2 = implode(" ", $text_2);
$text_2 = mb_strtoupper(mb_substr(mb_strtolower($text_2), 0, 1)).mb_substr(mb_strtolower($text_2), 1, null);
printf("$text_2");
?>