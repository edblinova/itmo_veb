<?php
$i = 0;
while (++$i) {
	switch ($i) {
	case 5:
		echo "Итерация 5";
		break;
	case 10:
		echo "Итерация 10";
		break;
} if($i==10) break;}
?>