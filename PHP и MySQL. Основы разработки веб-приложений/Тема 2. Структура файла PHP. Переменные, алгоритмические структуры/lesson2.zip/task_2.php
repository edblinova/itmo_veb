<form name="authForm" method="POST">
a=<input type="text" name="a">
</form>

<?php
$a=(int)$_POST['a'];
if($a==1):
	;
elseif($a==2):
	echo 'Hello world';
elseif($a==3):
	echo 'Hi world';
else:
	echo 'Goodbye world';
endif;
?>