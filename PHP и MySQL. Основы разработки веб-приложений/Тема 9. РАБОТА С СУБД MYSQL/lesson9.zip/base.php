<?php
    $mysqli = mysqli_connect("localhost", "edblinova", "5545", "newbase");

    if($mysqli === false){
        die("ERROR: Could not connect. ". mysqli_connect_error());
    }

    $res = $mysqli->query('SELECT * FROM zakaz;');

    echo "<table border=1>";
    echo"<tr><td>id</td><td>Имя</td>Фамилия<td>Электронный адрес</td>
    <td>Название товара</td><td>Колиичество</td></tr>";
    for ($row_no = 0; $row_no <= $res->num_rows - 1; $row_no++){
        $res->data_seek($row_no);
        $row = $data->fetch_assoc();
        echo "<tr>
        <td>".$row['id_tovar']."</td>
        <td>".$row['name']."</td>
        <td>".$row['fam']."</td>
        <td>".$row['email']."</td>
        <td>".$row['tovar']."</td>
        <td>".$row['col']."</td>
        <tr>";
    }

    echo "</table>";
    echo "<br>";
    vardump($res);
?>