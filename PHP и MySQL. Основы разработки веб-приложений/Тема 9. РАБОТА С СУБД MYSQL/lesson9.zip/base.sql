CREATE TABLE `newdatabase`.`zakaz`

(  `id_tovar` INT NOT NULL AUTO_INCREMENT ,
   `name` VARCHAR(255) NOT NULL ,
   `fam` VARCHAR(255) NOT NULL ,
   `email` VARCHAR(255) NOT NULL ,
   `tovar` VARCHAR(255) NOT NULL ,
   `col` INT NOT NULL ,
   PRIMARY KEY (`id_tovar`)) 
   ENGINE = InnoDB;


INSERT INTO `zakaz`
(`id_tovar`, `name`, `fam`, `email`, `tovar`, `col`)

VALUES
(NULL, 'Вася', 'Пупкин', 'vasya@yandex.ru', 'J7 Apple', '1')
(NULL, 'Иван', 'Петров', 'ivanpetrov@gmail.com', 'J7 Orange', '2')